/**
 * Simple API test script
 * Run with: node test-api.js
 */

const fetch = require('node-fetch');

const BASE_URL = 'http://localhost:3000';

async function testAPI() {
  console.log('🧪 Testing Gmail AI Backend API...\n');

  try {
    // Test 1: Health Check
    console.log('1. Testing Health Check...');
    const healthResponse = await fetch(`${BASE_URL}/health`);
    const healthData = await healthResponse.json();
    console.log('✅ Health Check:', healthData);
    console.log('');

    // Test 2: User Registration
    console.log('2. Testing User Registration...');
    const registerResponse = await fetch(`${BASE_URL}/api/auth/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'test@example.com',
        name: 'Test User',
        password: 'testpassword123'
      })
    });
    
    const registerData = await registerResponse.json();
    console.log('✅ Registration:', registerData);
    
    if (!registerData.success) {
      console.log('❌ Registration failed:', registerData.error);
      return;
    }
    
    const token = registerData.token;
    console.log('');

    // Test 3: AI Generation
    console.log('3. Testing AI Generation...');
    const aiResponse = await fetch(`${BASE_URL}/api/ai/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        emailContent: {
          subject: 'Meeting Request',
          sender: 'colleague@company.com',
          body: 'Hi, would you like to meet tomorrow at 2 PM to discuss the project?'
        },
        style: 'brief'
      })
    });
    
    const aiData = await aiResponse.json();
    console.log('✅ AI Generation:', aiData);
    console.log('');

    // Test 4: User Profile
    console.log('4. Testing User Profile...');
    const profileResponse = await fetch(`${BASE_URL}/api/users/profile`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    const profileData = await profileResponse.json();
    console.log('✅ User Profile:', profileData);
    console.log('');

    // Test 5: Usage Statistics
    console.log('5. Testing Usage Statistics...');
    const usageResponse = await fetch(`${BASE_URL}/api/ai/usage`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    const usageData = await usageResponse.json();
    console.log('✅ Usage Stats:', usageData);
    console.log('');

    console.log('🎉 All tests completed successfully!');

  } catch (error) {
    console.error('❌ Test failed:', error.message);
    
    if (error.code === 'ECONNREFUSED') {
      console.log('\n💡 Make sure the server is running:');
      console.log('   npm run dev');
    }
  }
}

// Run tests
testAPI();
