#!/usr/bin/env node

require('dotenv').config();

async function testSubscriptionAPI() {
  console.log('🧪 TESTING SUBSCRIPTION STATUS API');
  console.log('═'.repeat(80));
  
  const baseUrl = 'http://localhost:3000';
  const email = 'bob.bryden88@gmail.com';
  const password = 'YOUR_PASSWORD'; // You'll need to enter this
  
  try {
    // Step 1: Login to get token
    console.log('\n📝 Step 1: Logging in...');
    console.log(`Email: ${email}`);
    
    const loginResponse = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    
    if (!loginResponse.ok) {
      console.log('❌ Login failed:', await loginResponse.text());
      console.log('\n💡 Please update the password in this script and run again.');
      return;
    }
    
    const loginData = await loginResponse.json();
    console.log('✅ Login successful');
    console.log('Token:', loginData.token.substring(0, 20) + '...');
    console.log('User data from login:', JSON.stringify(loginData.user, null, 2));
    
    const token = loginData.token;
    
    // Step 2: Check subscription status
    console.log('\n📊 Step 2: Fetching subscription status...');
    
    const statusResponse = await fetch(`${baseUrl}/api/stripe/subscription-status`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!statusResponse.ok) {
      console.log('❌ Status check failed:', await statusResponse.text());
      return;
    }
    
    const statusData = await statusResponse.json();
    console.log('✅ Subscription status fetched');
    console.log('RAW API RESPONSE:', JSON.stringify(statusData, null, 2));
    
    // Step 3: Analyze the response
    console.log('\n🔍 Step 3: Analyzing response...');
    console.log(`Is Premium: ${statusData.user?.isPremium} ${statusData.user?.isPremium ? '✅' : '❌'}`);
    console.log(`Daily Usage: ${statusData.user?.dailyUsage}`);
    console.log(`Monthly Usage: ${statusData.user?.monthlyUsage}`);
    console.log(`Subscription ID: ${statusData.user?.subscriptionId || 'None'}`);
    
    // Step 4: Check what extension should see
    console.log('\n🎯 Step 4: Expected extension behavior:');
    if (statusData.user?.isPremium) {
      console.log('✅ Extension SHOULD show:');
      console.log('   - PREMIUM badge (green)');
      console.log('   - Premium benefits section');
      console.log('   - NO upgrade options');
      console.log('   - Manage Subscription button');
    } else {
      console.log('❌ Extension WILL show:');
      console.log('   - FREE badge (gray)');
      console.log('   - Usage limits');
      console.log('   - Upgrade options');
    }
    
    console.log('\n═'.repeat(80));
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

testSubscriptionAPI();
