# How to Add Cancel Subscription Button to Your Extension

## Quick Integration Guide

The cancel button isn't showing because the frontend code needs to be integrated into your Chrome extension. Here's how to add it:

---

## Option 1: Quick Integration (Recommended)

### Step 1: Include the Script

Add this to your extension's HTML file (wherever your sidebar is rendered):

```html
<!-- Add this before closing </body> tag -->
<script src="cancel-subscription-integration.js"></script>
```

Or if you're using a content script, add it to your `manifest.json`:

```json
{
  "content_scripts": [{
    "matches": ["https://mail.google.com/*"],
    "js": [
      "cancel-subscription-integration.js",
      "your-other-scripts.js"
    ]
  }]
}
```

### Step 2: Call the Function After Sidebar Renders

In your code where you load trial status, add this:

```javascript
// After you get trial status from API
async function loadTrialStatus() {
  try {
    const response = await fetch(`${API_BASE_URL}/api/trial/status`, {
      headers: {
        'Authorization': `Bearer ${getAuthToken()}`
      }
    });
    
    const trialStatus = await response.json();
    
    // ... your existing code to update UI ...
    
    // ADD THIS LINE:
    if (typeof initCancelSubscription === 'function') {
      initCancelSubscription(
        trialStatus, 
        'https://gmail-ai-backend.vercel.app', // Your API URL
        () => getAuthToken() // Your function to get auth token
      );
    }
  } catch (error) {
    console.error('Failed to load trial status:', error);
  }
}
```

### Step 3: Test

1. Reload your extension
2. Open Gmail
3. The cancel button should appear below the plan selection

---

## Option 2: Manual Integration

If you prefer to add it manually, here's the minimal code:

### Add This HTML Button

In your sidebar HTML, add this button where you want it (after the "CURRENT PLAN" section):

```html
<button id="cancel-subscription-btn" style="
  width: 100%;
  padding: 12px;
  margin-top: 20px;
  background-color: #dc3545;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
">Cancel Subscription</button>
```

### Add This JavaScript

```javascript
// Show button only if user has active subscription
function updateCancelButton(trialStatus) {
  const btn = document.getElementById('cancel-subscription-btn');
  if (!btn) return;
  
  const hasActiveSubscription = trialStatus.has_subscription && 
                                (trialStatus.subscription_status === 'active' || 
                                 trialStatus.subscription_status === 'trialing');
  
  if (hasActiveSubscription) {
    btn.style.display = 'block';
    btn.onclick = async () => {
      if (confirm('Are you sure you want to cancel your Pro subscription? You will lose access to Pro features immediately.')) {
        try {
          btn.disabled = true;
          btn.textContent = 'Cancelling...';
          
          const response = await fetch('https://gmail-ai-backend.vercel.app/api/stripe/cancel-subscription', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${getAuthToken()}`
            }
          });
          
          const data = await response.json();
          
          if (data.success) {
            alert('Subscription cancelled successfully');
            window.location.reload(); // Refresh to update UI
          } else {
            alert(data.error || 'Failed to cancel subscription');
            btn.disabled = false;
            btn.textContent = 'Cancel Subscription';
          }
        } catch (error) {
          alert('An error occurred. Please try again.');
          btn.disabled = false;
          btn.textContent = 'Cancel Subscription';
        }
      }
    };
  } else {
    btn.style.display = 'none';
  }
}

// Call this after loading trial status
// updateCancelButton(trialStatusData);
```

---

## Option 3: Direct DOM Injection

If you can't modify the HTML, inject it via JavaScript:

```javascript
function addCancelButton() {
  // Remove existing button
  const existing = document.getElementById('cancel-subscription-btn');
  if (existing) existing.remove();
  
  // Find where to insert (adjust selector based on your UI)
  const planSection = document.querySelector('[class*="plan"]') ||
                      document.querySelector('[class*="CURRENT"]') ||
                      document.body;
  
  // Create button
  const btn = document.createElement('button');
  btn.id = 'cancel-subscription-btn';
  btn.textContent = 'Cancel Subscription';
  btn.style.cssText = `
    width: 100%;
    padding: 12px;
    margin-top: 20px;
    background-color: #dc3545;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
  `;
  
  btn.onclick = async () => {
    if (confirm('Cancel your Pro subscription? You will lose access immediately.')) {
      try {
        btn.disabled = true;
        btn.textContent = 'Cancelling...';
        
        const token = localStorage.getItem('inkwell_token'); // Adjust to your token storage
        const response = await fetch('https://gmail-ai-backend.vercel.app/api/stripe/cancel-subscription', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        
        const data = await response.json();
        if (data.success) {
          alert('Cancelled! Refreshing...');
          window.location.reload();
        } else {
          alert(data.error);
          btn.disabled = false;
          btn.textContent = 'Cancel Subscription';
        }
      } catch (error) {
        alert('Error: ' + error.message);
        btn.disabled = false;
        btn.textContent = 'Cancel Subscription';
      }
    }
  };
  
  planSection.appendChild(btn);
}

// Call after sidebar loads
// addCancelButton();
```

---

## Testing

1. **Check if button appears:**
   - User must have `subscription_status: "trialing"` or `"active"`
   - User must have `has_subscription: true`

2. **Test cancellation:**
   - Click "Cancel Subscription"
   - Confirm in dialog
   - Should see success message
   - Page should refresh
   - Button should disappear
   - Status should show "Start Free Trial"

3. **Check backend logs:**
   - Look for `[CANCEL]` logs in Vercel
   - Should see successful cancellation

---

## Troubleshooting

### Button Not Showing

1. **Check trial status:**
   ```javascript
   console.log('Trial status:', trialStatus);
   console.log('Has subscription:', trialStatus.has_subscription);
   console.log('Status:', trialStatus.subscription_status);
   ```

2. **Verify function is called:**
   ```javascript
   console.log('initCancelSubscription available:', typeof initCancelSubscription);
   ```

3. **Check DOM:**
   ```javascript
   console.log('Cancel button exists:', document.getElementById('inkwell-cancel-subscription-btn'));
   ```

### Button Shows But Doesn't Work

1. **Check auth token:**
   ```javascript
   console.log('Auth token:', getAuthToken());
   ```

2. **Check API response:**
   - Open browser DevTools → Network tab
   - Click cancel button
   - Check the `/api/stripe/cancel-subscription` request
   - Look at response status and body

3. **Check console for errors:**
   - Look for JavaScript errors
   - Look for API errors

---

## Quick Test

To quickly test if the backend works, run this in browser console (on Gmail):

```javascript
// Replace with your actual token
const token = 'YOUR_JWT_TOKEN';

fetch('https://gmail-ai-backend.vercel.app/api/stripe/cancel-subscription', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  }
})
.then(r => r.json())
.then(data => console.log('Result:', data))
.catch(err => console.error('Error:', err));
```

If this works, the backend is fine and you just need to integrate the frontend button.

---

## Need Help?

If you're still having issues:

1. Check browser console for errors
2. Check Network tab for API calls
3. Verify your auth token is valid
4. Verify trial status has `has_subscription: true`
5. Check Vercel logs for `[CANCEL]` messages

The backend is working - you just need to add the frontend button to your extension UI!
