#!/usr/bin/env node

require('dotenv').config();
const nodemailer = require('nodemailer');

async function testDirectEmail() {
  console.log('🧪 TESTING EMAIL CONFIGURATION\n');
  console.log('═'.repeat(60));
  
  console.log('\n📋 Current Configuration:');
  console.log('─'.repeat(60));
  console.log('SMTP_HOST:', process.env.SMTP_HOST || '❌ NOT SET');
  console.log('SMTP_PORT:', process.env.SMTP_PORT || '❌ NOT SET');
  console.log('SMTP_USER:', process.env.SMTP_USER || '❌ NOT SET');
  console.log('SMTP_PASS:', process.env.SMTP_PASS ? '✅ SET (hidden)' : '❌ NOT SET');
  
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
    console.log('\n❌ EMAIL NOT CONFIGURED');
    console.log('─'.repeat(60));
    console.log('');
    console.log('To send real emails, add to .env file:');
    console.log('');
    console.log('SMTP_HOST=smtp.gmail.com');
    console.log('SMTP_PORT=587');
    console.log('SMTP_USER=your-email@gmail.com');
    console.log('SMTP_PASS=your-16-char-app-password');
    console.log('');
    console.log('Get Gmail App Password:');
    console.log('https://myaccount.google.com/apppasswords');
    console.log('');
    process.exit(1);
  }
  
  console.log('\n🔌 Creating SMTP Connection...');
  console.log('─'.repeat(60));
  
  const transporter = nodemailer.createTransporter({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT),
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });

  console.log('✅ Transporter created');
  
  console.log('\n📧 Sending Test Email...');
  console.log('─'.repeat(60));
  console.log('From:', process.env.SMTP_USER);
  console.log('To: bob.bryden88@gmail.com');
  console.log('Subject: Test Email - Gmail AI Assistant');
  
  try {
    const info = await transporter.sendMail({
      from: `"Gmail AI Assistant" <${process.env.SMTP_USER}>`,
      to: 'bob.bryden88@gmail.com',
      subject: 'Test Email - Gmail AI Assistant Password Reset',
      text: 'This is a test email. If you receive this, your email service is working correctly!',
      html: `
        <div style="font-family: Arial, sans-serif; padding: 20px;">
          <h2 style="color: #667eea;">✅ Email Service Test Successful!</h2>
          <p>This is a test email from your Gmail AI Assistant backend.</p>
          <p>If you receive this, your SMTP configuration is working correctly!</p>
          <hr style="border: 1px solid #ddd; margin: 20px 0;">
          <p style="font-size: 12px; color: #666;">
            Sent at: ${new Date().toLocaleString()}<br>
            From: Gmail AI Assistant Backend
          </p>
        </div>
      `
    });

    console.log('\n✅ EMAIL SENT SUCCESSFULLY!');
    console.log('─'.repeat(60));
    console.log('Message ID:', info.messageId);
    console.log('Response:', info.response);
    
    console.log('\n🎉 SUCCESS!');
    console.log('─'.repeat(60));
    console.log('Check bob.bryden88@gmail.com inbox');
    console.log('Email should arrive in 5-10 seconds');
    console.log('Check spam folder if not in inbox');
    
  } catch (error) {
    console.log('\n❌ EMAIL SENDING FAILED!');
    console.log('─'.repeat(60));
    console.error('Error Name:', error.name);
    console.error('Error Message:', error.message);
    console.error('Error Code:', error.code);
    
    console.log('\n🔧 Common Solutions:');
    console.log('─'.repeat(60));
    
    if (error.message.includes('Invalid login')) {
      console.log('❌ Invalid login credentials');
      console.log('✅ Solution: Use Gmail App Password, not regular password');
      console.log('   Get it here: https://myaccount.google.com/apppasswords');
    } else if (error.message.includes('ECONNECTION') || error.message.includes('ETIMEDOUT')) {
      console.log('❌ Connection timeout');
      console.log('✅ Solution: Check firewall, try port 587 or 465');
    } else if (error.message.includes('EAUTH')) {
      console.log('❌ Authentication failed');
      console.log('✅ Solution:');
      console.log('   1. Enable 2-Factor Authentication on Gmail');
      console.log('   2. Generate App Password');
      console.log('   3. Use that password in SMTP_PASS');
    } else {
      console.log('Full error:', error);
    }
  }
  
  console.log('\n═'.repeat(60));
}

testDirectEmail();
