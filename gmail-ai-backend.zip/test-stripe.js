#!/usr/bin/env node

/**
 * Stripe Integration Test Script
 * 
 * This script tests your Stripe integration with your specific Price IDs
 */

require('dotenv').config();
const Stripe = require('stripe');

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

async function testStripeIntegration() {
  console.log('🧪 Testing Stripe Integration with Your Price IDs\n');

  // Check environment variables
  const monthlyPriceId = process.env.STRIPE_PREMIUM_MONTHLY_PRICE_ID;
  const yearlyPriceId = process.env.STRIPE_PREMIUM_YEARLY_PRICE_ID;
  const secretKey = process.env.STRIPE_SECRET_KEY;

  console.log('📋 Environment Check:');
  console.log(`Secret Key: ${secretKey ? '✅ Set' : '❌ Missing'}`);
  console.log(`Monthly Price ID: ${monthlyPriceId ? '✅ Set' : '❌ Missing'}`);
  console.log(`Yearly Price ID: ${yearlyPriceId ? '✅ Set' : '❌ Missing'}`);
  console.log('');

  if (!secretKey || !monthlyPriceId || !yearlyPriceId) {
    console.log('❌ Missing required environment variables!');
    console.log('Please add them to your .env file:');
    console.log('STRIPE_SECRET_KEY="sk_test_..."');
    console.log('STRIPE_PREMIUM_MONTHLY_PRICE_ID="price_1SGQgoBj2yIrR2RDihOHgo3b"');
    console.log('STRIPE_PREMIUM_YEARLY_PRICE_ID="price_1SGQgoBj2yIrR2RDPLSBssOB"');
    return;
  }

  try {
    // Test retrieving Price IDs
    console.log('🔍 Testing Price ID Retrieval:');
    
    const [monthlyPrice, yearlyPrice] = await Promise.all([
      stripe.prices.retrieve(monthlyPriceId),
      stripe.prices.retrieve(yearlyPriceId)
    ]);

    console.log(`✅ Monthly Plan: $${(monthlyPrice.unit_amount / 100).toFixed(2)} ${monthlyPrice.currency.toUpperCase()} / ${monthlyPrice.recurring.interval}`);
    console.log(`✅ Yearly Plan: $${(yearlyPrice.unit_amount / 100).toFixed(2)} ${yearlyPrice.currency.toUpperCase()} / ${yearlyPrice.recurring.interval}`);
    console.log('');

    // Test creating a checkout session
    console.log('🧪 Testing Checkout Session Creation:');
    
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [
        {
          price: monthlyPriceId,
          quantity: 1,
        },
      ],
      success_url: 'http://localhost:3000/success?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: 'http://localhost:3000/cancel',
      metadata: {
        test: 'true',
        userId: 'test-user-123'
      }
    });

    console.log(`✅ Checkout session created: ${session.id}`);
    console.log(`✅ Checkout URL: ${session.url}`);
    console.log('');

    // Test pricing API endpoint
    console.log('🌐 Testing API Endpoints:');
    
    try {
      const response = await fetch('http://localhost:3000/api/stripe/pricing');
      if (response.ok) {
        const data = await response.json();
        console.log('✅ /api/stripe/pricing endpoint working');
        console.log('   Response:', JSON.stringify(data, null, 2));
      } else {
        console.log('❌ /api/stripe/pricing endpoint failed:', response.status);
      }
    } catch (error) {
      console.log('❌ /api/stripe/pricing endpoint error:', error.message);
      console.log('   Make sure your backend server is running: npm run dev');
    }

    console.log('');
    console.log('🎯 Next Steps:');
    console.log('1. Add your Stripe secret key to .env file');
    console.log('2. Restart your backend: npm run dev');
    console.log('3. Test the complete payment flow in your extension');
    console.log('4. Use test cards: 4242 4242 4242 4242 (success) or 4000 0000 0000 0002 (decline)');

  } catch (error) {
    console.error('❌ Stripe test failed:', error.message);
    
    if (error.message.includes('No such price')) {
      console.log('💡 Solution: Check your Price IDs in Stripe Dashboard');
    } else if (error.message.includes('Invalid API Key')) {
      console.log('💡 Solution: Check your Stripe secret key in .env file');
    }
  }
}

// Run the test
testStripeIntegration().catch(console.error);
