#!/usr/bin/env node

require('dotenv').config();

async function testForgotPasswordFlow() {
  console.log('🧪 TESTING COMPLETE PASSWORD RESET FLOW\n');
  console.log('═'.repeat(60));
  
  const baseUrl = 'http://localhost:3000';
  const testEmail = 'bob.bryden88@gmail.com';
  
  try {
    console.log('\n📝 Step 1: Requesting password reset...');
    console.log('Email:', testEmail);
    
    const response = await fetch(`${baseUrl}/api/auth/forgot-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: testEmail })
    });
    
    const data = await response.json();
    
    console.log('\n📊 Response:');
    console.log('Status:', response.status);
    console.log('Success:', data.success);
    console.log('Message:', data.message);
    
    if (data.success) {
      console.log('\n✅ PASSWORD RESET REQUEST SUCCESSFUL!');
      console.log('═'.repeat(60));
      console.log('\n📧 Email sent to:', testEmail);
      console.log('\n🎯 Next Steps:');
      console.log('1. Check bob.bryden88@gmail.com inbox');
      console.log('2. Look for email from "Gmail AI Assistant"');
      console.log('3. Click the reset link in the email');
      console.log('4. Enter your new password');
      console.log('5. Login to extension with new password!');
      
      console.log('\n⏱️  Email should arrive in 5-30 seconds');
      console.log('📁 Check spam folder if not in inbox');
      
      console.log('\n💡 Email Details:');
      console.log('From: ceosmartresponces@gmail.com');
      console.log('To: bob.bryden88@gmail.com');
      console.log('Subject: Reset Your Gmail AI Assistant Password');
      
    } else {
      console.log('\n❌ Failed:', data.error || data.message);
    }
    
    console.log('\n═'.repeat(60));
    
  } catch (error) {
    console.error('\n❌ Error:', error.message);
  }
}

testForgotPasswordFlow();
