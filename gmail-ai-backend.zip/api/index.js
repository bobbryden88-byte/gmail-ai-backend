// Vercel serverless function entry point
// This file is required for Vercel to properly route requests
module.exports = require('../src/app.js');
