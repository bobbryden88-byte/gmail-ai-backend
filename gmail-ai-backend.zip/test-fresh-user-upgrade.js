#!/usr/bin/env node

require('dotenv').config();

async function testFreshUserUpgrade() {
  console.log('🧪 Testing Premium Upgrade with Fresh User\n');

  const baseUrl = 'http://localhost:3000';
  const timestamp = Date.now();
  const testEmail = `test${timestamp}@example.com`;
  const testPassword = 'testpass123';

  try {
    // Step 1: Register a fresh test user
    console.log('📝 Step 1: Registering fresh test user...');
    console.log('Email:', testEmail);
    
    const registerResponse = await fetch(`${baseUrl}/api/auth/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: testEmail,
        password: testPassword,
        name: 'Test User'
      })
    });

    if (!registerResponse.ok) {
      const errorData = await registerResponse.json();
      console.log('❌ Registration failed:', errorData.error);
      return;
    }

    const registerData = await registerResponse.json();
    const userToken = registerData.token;
    
    console.log('✅ User registered successfully');
    console.log('User ID:', registerData.user.id);
    console.log('Is Premium:', registerData.user.isPremium);

    // Step 2: Check initial subscription status
    console.log('\n📊 Step 2: Checking initial subscription status...');
    const statusResponse = await fetch(`${baseUrl}/api/stripe/subscription-status`, {
      headers: {
        'Authorization': `Bearer ${userToken}`
      }
    });

    if (statusResponse.ok) {
      const statusData = await statusResponse.json();
      console.log('✅ Subscription status retrieved');
      console.log('Is Premium:', statusData.user.isPremium);
      console.log('Daily Usage:', statusData.user.dailyUsage);
      console.log('Monthly Usage:', statusData.user.monthlyUsage);
    }

    // Step 3: Create checkout session for monthly plan
    console.log('\n💳 Step 3: Creating checkout session for MONTHLY plan...');
    const monthlyCheckoutResponse = await fetch(`${baseUrl}/api/stripe/create-checkout-session`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${userToken}`
      },
      body: JSON.stringify({
        planType: 'monthly'
      })
    });

    if (monthlyCheckoutResponse.ok) {
      const monthlyCheckoutData = await monthlyCheckoutResponse.json();
      console.log('✅ MONTHLY checkout session created successfully!');
      console.log('Session ID:', monthlyCheckoutData.sessionId);
      console.log('Plan Type:', monthlyCheckoutData.planType);
      console.log('\n🎯 MONTHLY CHECKOUT URL ($7.99 CAD/month):');
      console.log(monthlyCheckoutData.checkoutUrl);
    } else {
      const errorData = await monthlyCheckoutResponse.json();
      console.log('❌ Monthly checkout session creation failed:', errorData.error);
    }

    // Step 4: Create checkout session for yearly plan
    console.log('\n💳 Step 4: Creating checkout session for YEARLY plan...');
    const yearlyCheckoutResponse = await fetch(`${baseUrl}/api/stripe/create-checkout-session`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${userToken}`
      },
      body: JSON.stringify({
        planType: 'yearly'
      })
    });

    if (yearlyCheckoutResponse.ok) {
      const yearlyCheckoutData = await yearlyCheckoutResponse.json();
      console.log('✅ YEARLY checkout session created successfully!');
      console.log('Session ID:', yearlyCheckoutData.sessionId);
      console.log('Plan Type:', yearlyCheckoutData.planType);
      console.log('\n🎯 YEARLY CHECKOUT URL ($79.99 CAD/year):');
      console.log(yearlyCheckoutData.checkoutUrl);
    } else {
      const errorData = await yearlyCheckoutResponse.json();
      console.log('❌ Yearly checkout session creation failed:', errorData.error);
    }

    console.log('\n🎯 HOW TO TEST THE PAYMENT:');
    console.log('1. Copy one of the checkout URLs above');
    console.log('2. Open it in your browser');
    console.log('3. Use test card: 4242 4242 4242 4242');
    console.log('4. Expiry: 12/25, CVC: 123, ZIP: 12345');
    console.log('5. Complete the payment');
    console.log('6. Check if user becomes premium in your database');

    console.log('\n🧪 TEST CARDS:');
    console.log('✅ Success: 4242 4242 4242 4242');
    console.log('❌ Decline: 4000 0000 0000 0002');
    console.log('🔐 3D Secure: 4000 0025 0000 3155');

  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

testFreshUserUpgrade().catch(console.error);
