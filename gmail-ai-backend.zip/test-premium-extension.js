#!/usr/bin/env node

require('dotenv').config();

async function testPremiumExtension() {
  console.log('🧪 Testing Premium Extension Integration\n');

  const baseUrl = 'http://localhost:3000';
  const timestamp = Date.now();
  const testEmail = `test${timestamp}@example.com`;

  try {
    // Step 1: Register a fresh test user
    console.log('📝 Step 1: Registering test user for extension testing...');
    console.log('Email:', testEmail);
    
    const registerResponse = await fetch(`${baseUrl}/api/auth/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: testEmail,
        password: 'testpass123',
        name: 'Extension Test User'
      })
    });

    if (!registerResponse.ok) {
      const errorData = await registerResponse.json();
      console.log('❌ Registration failed:', errorData.error);
      return;
    }

    const registerData = await registerResponse.json();
    const userToken = registerData.token;
    
    console.log('✅ User registered successfully');
    console.log('User ID:', registerData.user.id);
    console.log('Is Premium:', registerData.user.isPremium);
    console.log('Token:', userToken.substring(0, 20) + '...');

    // Step 2: Test subscription status endpoint
    console.log('\n📊 Step 2: Testing subscription status endpoint...');
    const statusResponse = await fetch(`${baseUrl}/api/stripe/subscription-status`, {
      headers: {
        'Authorization': `Bearer ${userToken}`
      }
    });

    if (statusResponse.ok) {
      const statusData = await statusResponse.json();
      console.log('✅ Subscription status endpoint working');
      console.log('Is Premium:', statusData.user.isPremium);
      console.log('Daily Usage:', statusData.user.dailyUsage);
      console.log('Monthly Usage:', statusData.user.monthlyUsage);
    } else {
      console.log('❌ Subscription status endpoint failed:', await statusResponse.text());
    }

    // Step 3: Test monthly upgrade
    console.log('\n💳 Step 3: Testing monthly upgrade...');
    const monthlyResponse = await fetch(`${baseUrl}/api/stripe/create-checkout-session`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${userToken}`
      },
      body: JSON.stringify({ planType: 'monthly' })
    });

    if (monthlyResponse.ok) {
      const monthlyData = await monthlyResponse.json();
      console.log('✅ Monthly upgrade working!');
      console.log('Session ID:', monthlyData.sessionId);
      console.log('Plan Type:', monthlyData.planType);
      console.log('\n🎯 MONTHLY CHECKOUT URL ($7.99 CAD/month):');
      console.log(monthlyData.checkoutUrl);
    } else {
      const errorData = await monthlyResponse.json();
      console.log('❌ Monthly upgrade failed:', errorData.error);
    }

    // Step 4: Test yearly upgrade
    console.log('\n💳 Step 4: Testing yearly upgrade...');
    const yearlyResponse = await fetch(`${baseUrl}/api/stripe/create-checkout-session`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${userToken}`
      },
      body: JSON.stringify({ planType: 'yearly' })
    });

    if (yearlyResponse.ok) {
      const yearlyData = await yearlyResponse.json();
      console.log('✅ Yearly upgrade working!');
      console.log('Session ID:', yearlyData.sessionId);
      console.log('Plan Type:', yearlyData.planType);
      console.log('\n🎯 YEARLY CHECKOUT URL ($79.99 CAD/year):');
      console.log(yearlyData.checkoutUrl);
    } else {
      const errorData = await yearlyResponse.json();
      console.log('❌ Yearly upgrade failed:', errorData.error);
    }

    console.log('\n🎉 EXTENSION TESTING COMPLETE!');
    console.log('\n📝 Next Steps:');
    console.log('1. Open your Chrome extension');
    console.log('2. Login with:', testEmail);
    console.log('3. Password: testpass123');
    console.log('4. Test the upgrade buttons');
    console.log('5. Use test card: 4242 4242 4242 4242');
    
    console.log('\n🧪 TEST CARDS:');
    console.log('✅ Success: 4242 4242 4242 4242');
    console.log('❌ Decline: 4000 0000 0000 0002');
    console.log('🔐 3D Secure: 4000 0025 0000 3155');
    
    console.log('\n💡 Test Details:');
    console.log('Expiry: 12/25, CVC: 123, ZIP: 12345');

  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

testPremiumExtension().catch(console.error);
