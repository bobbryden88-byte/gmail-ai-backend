#!/usr/bin/env node

require('dotenv').config();

async function testPremiumUpgrade() {
  console.log('🧪 Testing Premium Upgrade Flow\n');

  // First, let's test if the backend is running
  try {
    const healthResponse = await fetch('http://localhost:3000/health');
    const healthData = await healthResponse.json();
    console.log('✅ Backend is running:', healthData.status);
  } catch (error) {
    console.log('❌ Backend is not running. Start it with: npm run dev');
    return;
  }

  // Test pricing endpoint
  console.log('\n📋 Testing Pricing Endpoint:');
  try {
    const pricingResponse = await fetch('http://localhost:3000/api/stripe/pricing');
    const pricingData = await pricingResponse.json();
    console.log('✅ Pricing endpoint working');
    console.log('Response:', JSON.stringify(pricingData, null, 2));
  } catch (error) {
    console.log('❌ Pricing endpoint error:', error.message);
  }

  // Test creating a checkout session (requires authentication)
  console.log('\n🧪 Testing Checkout Session Creation:');
  console.log('Note: This requires a valid user token');
  
  // You would need to:
  // 1. Register a test user
  // 2. Get a JWT token
  // 3. Use that token to create a checkout session
  
  console.log('\n📝 To test the full flow:');
  console.log('1. Register a test user via /api/auth/register');
  console.log('2. Login to get a JWT token');
  console.log('3. Use the token to create a checkout session');
  console.log('4. Complete the payment with test card: 4242 4242 4242 4242');
  
  console.log('\n🎯 Test Cards to Use:');
  console.log('✅ Success: 4242 4242 4242 4242');
  console.log('❌ Decline: 4000 0000 0000 0002');
  console.log('🔐 3D Secure: 4000 0025 0000 3155');
  
  console.log('\n💡 Test Details:');
  console.log('Expiry: Any future date (e.g., 12/25)');
  console.log('CVC: Any 3 digits (e.g., 123)');
  console.log('ZIP: Any 5 digits (e.g., 12345)');
}

testPremiumUpgrade().catch(console.error);
