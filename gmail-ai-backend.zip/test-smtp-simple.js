#!/usr/bin/env node

require('dotenv').config();

async function testSMTP() {
  console.log('🧪 Testing SMTP Email Sending\n');
  console.log('═'.repeat(60));
  
  // Import after .env is loaded
  const nodemailer = require('nodemailer');
  
  console.log('\n📋 Configuration:');
  console.log('Host:', process.env.SMTP_HOST);
  console.log('Port:', process.env.SMTP_PORT);
  console.log('User:', process.env.SMTP_USER);
  console.log('Pass:', process.env.SMTP_PASS ? '✅ SET' : '❌ NOT SET');
  
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
    console.log('\n❌ SMTP credentials not configured');
    process.exit(1);
  }
  
  console.log('\n🔌 Creating transporter...');
  
  try {
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT),
      secure: false,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      },
      debug: true, // Show SMTP traffic
      logger: true // Log to console
    });
    
    console.log('✅ Transporter created');
    
    console.log('\n📧 Sending test email to bob.bryden88@gmail.com...');
    
    const info = await transporter.sendMail({
      from: `"Gmail AI Assistant" <${process.env.SMTP_USER}>`,
      to: 'bob.bryden88@gmail.com',
      subject: '✅ Test Email - Gmail AI Assistant',
      text: 'This is a test email. If you receive this, your SMTP is working!',
      html: `
        <div style="font-family: Arial; padding: 20px; background: #f8f9fa; border-radius: 8px;">
          <h2 style="color: #667eea;">✅ Email Service Test Successful!</h2>
          <p>This is a test email from Gmail AI Assistant backend.</p>
          <p>If you receive this, your SMTP configuration is working correctly!</p>
          <p style="font-size: 12px; color: #666; margin-top: 20px;">
            Sent at: ${new Date().toLocaleString()}<br>
            From: Gmail AI Assistant
          </p>
        </div>
      `
    });
    
    console.log('\n═'.repeat(60));
    console.log('🎉 SUCCESS! EMAIL SENT!');
    console.log('═'.repeat(60));
    console.log('Message ID:', info.messageId);
    console.log('Response:', info.response);
    console.log('\n📬 Check bob.bryden88@gmail.com inbox!');
    console.log('Email should arrive in 5-10 seconds');
    console.log('Check spam folder if not in inbox');
    console.log('');
    
  } catch (error) {
    console.log('\n═'.repeat(60));
    console.log('❌ FAILED TO SEND EMAIL');
    console.log('═'.repeat(60));
    console.error('Error:', error.message);
    
    if (error.code === 'EAUTH') {
      console.log('\n🔧 FIX: Authentication failed');
      console.log('The Gmail app password is incorrect or invalid.');
      console.log('\nSteps to fix:');
      console.log('1. Go to: https://myaccount.google.com/apppasswords');
      console.log('2. Delete the old app password');
      console.log('3. Create a new app password');
      console.log('4. Update SMTP_PASS in .env file');
      console.log('5. Restart backend and try again');
    } else if (error.code === 'ECONNECTION') {
      console.log('\n🔧 FIX: Connection failed');
      console.log('Check your internet connection or firewall settings.');
    } else {
      console.log('\nFull error details:', error);
    }
    
    process.exit(1);
  }
}

testSMTP();
