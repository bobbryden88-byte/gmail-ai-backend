# Sidebar Cancel Button Integration Guide

## Quick Integration (3 Steps)

### Step 1: Include the Script

Add this to your extension's HTML or content script:

```html
<script src="gmail-sidebar-cancel-integration.js"></script>
```

Or in your `manifest.json`:

```json
{
  "content_scripts": [{
    "matches": ["https://mail.google.com/*"],
    "js": ["gmail-sidebar-cancel-integration.js"]
  }]
}
```

### Step 2: Call After Sidebar Renders

In your code where you load trial status, add this:

```javascript
// After you get trial status from API
async function loadTrialStatus() {
  try {
    const response = await fetch(`${API_BASE_URL}/api/trial/status`, {
      headers: {
        'Authorization': `Bearer ${getAuthToken()}`
      }
    });
    
    const trialStatus = await response.json();
    
    // ... your existing code to update UI ...
    
    // ADD THIS LINE:
    if (typeof initCancelButton === 'function') {
      initCancelButton(
        trialStatus,                    // Trial status from API
        () => getAuthToken(),            // Function to get auth token
        loadTrialStatus                  // Function to refresh UI after cancel
      );
    }
  } catch (error) {
    console.error('Failed to load trial status:', error);
  }
}
```

### Step 3: Test

1. Reload your extension
2. Open Gmail
3. The cancel button should appear below the Pro Plan section

---

## How It Works

### Automatic Detection

The script automatically:
- ✅ Finds the Pro Plan section in your sidebar
- ✅ Detects if user has active subscription
- ✅ Adds cancel button in the right place
- ✅ Removes button when subscription is cancelled

### Button Visibility

Button appears when:
- `has_subscription === true` AND
- `subscription_status === "active"` OR `"trialing"` OR
- `is_premium === true`

Button hides when:
- User is on free plan
- Subscription is cancelled
- No active subscription

### Insertion Strategy

The script tries multiple strategies to find where to insert the button:

1. Looks for "CURRENT PLAN" text
2. Finds Pro Plan section by class names
3. Finds Monthly/Yearly buttons
4. Finds "Secure payment via Stripe" text
5. Falls back to sidebar container

---

## API Configuration

### Update API URL

If your backend URL is different, edit the script:

```javascript
const CONFIG = {
  API_BASE_URL: 'https://your-backend-url.com', // Change this
  // ...
};
```

Or pass it when calling:

```javascript
// The script uses CONFIG.API_BASE_URL by default
// You can modify it before calling initCancelButton
```

---

## Customization

### Change Button Text

Edit in the script:

```javascript
const CONFIG = {
  BUTTON_TEXT: 'Cancel Subscription',  // Change this
  // ...
};
```

### Change Button Style

The button uses inline styles. To customize, modify `applyButtonStyles()` function:

```javascript
function applyButtonStyles(button) {
  button.style.cssText = `
    width: 100%;
    padding: 12px 16px;
    margin: 16px 0;
    background-color: #dc3545;  // Change color
    // ... other styles
  `;
}
```

### Change Dialog Text

Edit `showCancelConfirmationDialog()` function to customize the confirmation message.

---

## Integration Examples

### Example 1: Simple Integration

```javascript
// After sidebar loads
window.addEventListener('load', () => {
  // Get trial status
  fetch('/api/trial/status', {
    headers: { 'Authorization': `Bearer ${token}` }
  })
  .then(r => r.json())
  .then(data => {
    // Initialize cancel button
    if (typeof initCancelButton === 'function') {
      initCancelButton(data, () => token, () => location.reload());
    }
  });
});
```

### Example 2: With Existing Code

```javascript
// Your existing function
function updateSidebarUI(trialStatus) {
  // ... your existing UI update code ...
  
  // Add cancel button
  if (typeof initCancelButton === 'function') {
    initCancelButton(
      trialStatus,
      getAuthToken,
      () => {
        loadTrialStatus(); // Refresh after cancel
        updateSidebarUI(trialStatus); // Update UI
      }
    );
  }
}
```

### Example 3: Manual Trigger

```javascript
// Call manually when needed
function showCancelButton() {
  const trialStatus = {
    has_subscription: true,
    subscription_status: 'active',
    is_premium: true
  };
  
  initCancelButton(
    trialStatus,
    () => localStorage.getItem('token'),
    () => console.log('Cancelled!')
  );
}
```

---

## Troubleshooting

### Button Not Appearing

1. **Check trial status:**
   ```javascript
   console.log('Trial status:', trialStatus);
   console.log('Has subscription:', trialStatus.has_subscription);
   ```

2. **Verify function is available:**
   ```javascript
   console.log('initCancelButton available:', typeof initCancelButton);
   ```

3. **Check DOM:**
   ```javascript
   console.log('Cancel button exists:', document.getElementById('inkwell-cancel-subscription-btn'));
   ```

4. **Check insertion point:**
   - Open DevTools
   - Look for "CURRENT PLAN" or Pro Plan section
   - Button should be inserted right after it

### Button Shows But Doesn't Work

1. **Check auth token:**
   ```javascript
   console.log('Auth token:', getAuthToken());
   ```

2. **Check API response:**
   - Open DevTools → Network tab
   - Click cancel button
   - Check `/api/stripe/cancel-subscription` request
   - Look at response

3. **Check console for errors:**
   - Look for JavaScript errors
   - Look for API errors

### Button in Wrong Location

The script tries multiple strategies to find the insertion point. If it's in the wrong place:

1. **Add a specific class to your Pro Plan section:**
   ```html
   <div class="pro-plan-section">
     <!-- Your Pro Plan content -->
   </div>
   ```

2. **Or modify `findInsertionPoint()` in the script** to use your specific selector.

---

## Testing Checklist

- [ ] Button appears when user has Pro subscription
- [ ] Button appears when user has trial subscription
- [ ] Button does NOT appear when user is on free plan
- [ ] Button does NOT appear when subscription is cancelled
- [ ] Clicking button shows confirmation dialog
- [ ] "Keep Plan" closes dialog without cancelling
- [ ] "Cancel Plan" triggers cancellation
- [ ] Loading state shows while cancelling
- [ ] Success message appears after cancellation
- [ ] Button disappears after cancellation
- [ ] UI refreshes after cancellation
- [ ] Pro features are disabled after cancellation

---

## Files

- **`gmail-sidebar-cancel-integration.js`** - Complete integration script
- **`SIDEBAR_CANCEL_INTEGRATION_GUIDE.md`** - This guide

---

## Support

If you're still having issues:

1. Check browser console for errors
2. Check Network tab for API calls
3. Verify auth token is valid
4. Verify trial status has correct fields
5. Check Vercel logs for `[CANCEL]` messages

The backend is working - you just need to integrate the frontend button!
