# Cancel Subscription - Testing Checklist

## ✅ Backend Status: READY

- ✅ Endpoint: `POST /api/stripe/cancel-subscription`
- ✅ Immediate cancellation implemented
- ✅ Database update logic complete
- ✅ Error handling in place
- ✅ Logging added

## ⚠️ Frontend Status: NEEDS INTEGRATION

The integration script is ready, but you need to add it to your Chrome extension.

---

## Pre-Testing Checklist

### Backend (Already Done ✅)
- [x] Cancel endpoint created
- [x] Database update logic implemented
- [x] Error handling added
- [x] Logging added

### Frontend (You Need To Do)
- [ ] Copy `gmail-sidebar-cancel-integration.js` to your extension folder
- [ ] Include script in your extension (manifest.json or HTML)
- [ ] Call `initCancelButton()` after loading trial status
- [ ] Verify auth token function works

---

## Quick Integration Steps

### 1. Copy Script to Extension
```bash
# Copy the integration script to your extension folder
cp public/gmail-sidebar-cancel-integration.js /path/to/your/extension/
```

### 2. Add to Manifest
```json
{
  "content_scripts": [{
    "matches": ["https://mail.google.com/*"],
    "js": ["gmail-sidebar-cancel-integration.js"]
  }]
}
```

### 3. Call After Loading Trial Status
```javascript
// In your loadTrialStatus() function:
if (typeof initCancelButton === 'function') {
  initCancelButton(
    trialStatus,
    () => getAuthToken(),
    loadTrialStatus
  );
}
```

---

## Testing Steps

### Test 1: Verify Button Appears
1. Open Gmail with your extension
2. User should have Pro subscription or trial
3. **Expected:** Cancel button appears below Pro Plan section

### Test 2: Verify Button Hidden
1. User on free plan (no subscription)
2. **Expected:** Cancel button does NOT appear

### Test 3: Cancel Subscription
1. Click "Cancel Subscription" button
2. **Expected:** Confirmation dialog appears
3. Click "Cancel Plan" in dialog
4. **Expected:** 
   - Button shows "Cancelling..."
   - Success message appears
   - Button disappears
   - UI refreshes to show free plan

### Test 4: Verify Backend
1. Check Vercel logs for `[CANCEL]` messages
2. **Expected:** See logs like:
   ```
   🔄 [CANCEL] User requesting subscription cancellation
   ✅ [CANCEL] Subscription cancelled in Stripe
   ✅ [CANCEL] Database updated for user
   ```

### Test 5: Verify Database
1. After cancellation, check database:
   ```sql
   SELECT subscriptionStatus, isPremium 
   FROM users 
   WHERE email = 'test@example.com';
   ```
2. **Expected:**
   - `subscriptionStatus: "canceled"`
   - `isPremium: false`

---

## Troubleshooting

### Button Not Appearing
- [ ] Check console for errors
- [ ] Verify `initCancelButton` is called
- [ ] Verify trial status has `has_subscription: true`
- [ ] Check if insertion point is found

### Button Doesn't Work
- [ ] Check Network tab for API call
- [ ] Verify auth token is valid
- [ ] Check API response in Network tab
- [ ] Check Vercel logs for errors

### Backend Errors
- [ ] Check Vercel logs for `[CANCEL]` messages
- [ ] Verify `STRIPE_SECRET_KEY` is set
- [ ] Verify database connection works
- [ ] Check subscription exists in Stripe

---

## Quick Test (Backend Only)

Test the backend directly without UI:

```javascript
// In browser console on Gmail:
const token = localStorage.getItem('inkwell_token'); // or wherever you store it

fetch('https://gmail-ai-backend.vercel.app/api/stripe/cancel-subscription', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  }
})
.then(r => r.json())
.then(data => {
  console.log('Result:', data);
  if (data.success) {
    alert('Cancelled! Refresh page.');
    window.location.reload();
  } else {
    alert('Error: ' + (data.error || data.message));
  }
});
```

If this works, backend is fine - you just need to integrate the frontend button.

---

## Ready to Test?

**Backend:** ✅ Ready  
**Frontend Script:** ✅ Ready  
**Integration:** ⚠️ You need to add the script to your extension

Once you've added the script and called `initCancelButton()`, you're ready to test!
