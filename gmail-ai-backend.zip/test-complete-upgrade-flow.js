#!/usr/bin/env node

require('dotenv').config();

async function testCompleteUpgradeFlow() {
  console.log('🧪 Complete Premium Upgrade Test Flow\n');

  const baseUrl = 'http://localhost:3000';
  let userToken = null;

  try {
    // Step 1: Register a test user
    console.log('📝 Step 1: Registering test user...');
    const registerResponse = await fetch(`${baseUrl}/api/auth/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'test@example.com',
        password: 'testpass123',
        name: 'Test User'
      })
    });

    if (registerResponse.ok) {
      const registerData = await registerResponse.json();
      userToken = registerData.token;
      console.log('✅ User registered successfully');
      console.log('User ID:', registerData.user.id);
      console.log('Token received:', userToken ? 'Yes' : 'No');
    } else {
      const errorData = await registerResponse.json();
      if (errorData.error.includes('already exists')) {
        console.log('ℹ️  User already exists, trying to login...');
        
        // Try to login instead
        const loginResponse = await fetch(`${baseUrl}/api/auth/login`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            email: 'test@example.com',
            password: 'testpass123'
          })
        });

        if (loginResponse.ok) {
          const loginData = await loginResponse.json();
          userToken = loginData.token;
          console.log('✅ User logged in successfully');
          console.log('User ID:', loginData.user.id);
        } else {
          console.log('❌ Login failed:', await loginResponse.text());
          return;
        }
      } else {
        console.log('❌ Registration failed:', errorData.error);
        return;
      }
    }

    // Step 2: Test subscription status
    console.log('\n📊 Step 2: Checking subscription status...');
    const statusResponse = await fetch(`${baseUrl}/api/stripe/subscription-status`, {
      headers: {
        'Authorization': `Bearer ${userToken}`
      }
    });

    if (statusResponse.ok) {
      const statusData = await statusResponse.json();
      console.log('✅ Subscription status retrieved');
      console.log('Is Premium:', statusData.user.isPremium);
      console.log('Daily Usage:', statusData.user.dailyUsage);
      console.log('Monthly Usage:', statusData.user.monthlyUsage);
    }

    // Step 3: Create checkout session for monthly plan
    console.log('\n💳 Step 3: Creating checkout session for monthly plan...');
    const checkoutResponse = await fetch(`${baseUrl}/api/stripe/create-checkout-session`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${userToken}`
      },
      body: JSON.stringify({
        planType: 'monthly'
      })
    });

    if (checkoutResponse.ok) {
      const checkoutData = await checkoutResponse.json();
      console.log('✅ Checkout session created successfully!');
      console.log('Session ID:', checkoutData.sessionId);
      console.log('Plan Type:', checkoutData.planType);
      console.log('\n🎯 CHECKOUT URL:');
      console.log(checkoutData.checkoutUrl);
      
      console.log('\n📝 TO COMPLETE THE TEST:');
      console.log('1. Copy the checkout URL above');
      console.log('2. Open it in your browser');
      console.log('3. Use test card: 4242 4242 4242 4242');
      console.log('4. Complete the payment');
      console.log('5. Check if user becomes premium');
      
    } else {
      const errorData = await checkoutResponse.json();
      console.log('❌ Checkout session creation failed:', errorData.error);
      
      if (errorData.alreadyPremium) {
        console.log('ℹ️  User is already premium - this is expected if you tested before');
      }
    }

    // Step 4: Test yearly plan as well
    console.log('\n💳 Step 4: Creating checkout session for yearly plan...');
    const yearlyCheckoutResponse = await fetch(`${baseUrl}/api/stripe/create-checkout-session`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${userToken}`
      },
      body: JSON.stringify({
        planType: 'yearly'
      })
    });

    if (yearlyCheckoutResponse.ok) {
      const yearlyCheckoutData = await yearlyCheckoutResponse.json();
      console.log('✅ Yearly checkout session created successfully!');
      console.log('Session ID:', yearlyCheckoutData.sessionId);
      console.log('Plan Type:', yearlyCheckoutData.planType);
      console.log('\n🎯 YEARLY CHECKOUT URL:');
      console.log(yearlyCheckoutData.checkoutUrl);
    } else {
      const errorData = await yearlyCheckoutResponse.json();
      console.log('❌ Yearly checkout session creation failed:', errorData.error);
    }

  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }

  console.log('\n🎯 TEST CARDS TO USE:');
  console.log('✅ Success: 4242 4242 4242 4242');
  console.log('❌ Decline: 4000 0000 0000 0002');
  console.log('🔐 3D Secure: 4000 0025 0000 3155');
  console.log('\n💡 Test Details:');
  console.log('Expiry: 12/25 (any future date)');
  console.log('CVC: 123 (any 3 digits)');
  console.log('ZIP: 12345 (any 5 digits)');
}

testCompleteUpgradeFlow().catch(console.error);
