#!/usr/bin/env node

require('dotenv').config();
const Stripe = require('stripe');

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

async function testSpecificPrices() {
  console.log('🧪 Testing Your Specific Price IDs\n');

  const monthlyPriceId = 'price_1SGQgoBj2yIrR2RDihOHgo3b';
  const yearlyPriceId = 'price_1SGQgoBj2yIrR2RDPLSBssOB';

  console.log('Testing Monthly Price ID:', monthlyPriceId);
  try {
    const monthlyPrice = await stripe.prices.retrieve(monthlyPriceId);
    console.log('✅ Monthly Price Found:');
    console.log(`   Amount: $${(monthlyPrice.unit_amount / 100).toFixed(2)} ${monthlyPrice.currency.toUpperCase()}`);
    console.log(`   Interval: ${monthlyPrice.recurring.interval}`);
    console.log(`   Product: ${monthlyPrice.product}`);
    console.log(`   Active: ${monthlyPrice.active}`);
  } catch (error) {
    console.log('❌ Monthly Price Error:', error.message);
  }

  console.log('\nTesting Yearly Price ID:', yearlyPriceId);
  try {
    const yearlyPrice = await stripe.prices.retrieve(yearlyPriceId);
    console.log('✅ Yearly Price Found:');
    console.log(`   Amount: $${(yearlyPrice.unit_amount / 100).toFixed(2)} ${yearlyPrice.currency.toUpperCase()}`);
    console.log(`   Interval: ${yearlyPrice.recurring.interval}`);
    console.log(`   Product: ${yearlyPrice.product}`);
    console.log(`   Active: ${yearlyPrice.active}`);
  } catch (error) {
    console.log('❌ Yearly Price Error:', error.message);
  }

  console.log('\n🔍 Let me check what Stripe account we\'re connected to:');
  try {
    const account = await stripe.accounts.retrieve();
    console.log(`Account ID: ${account.id}`);
    console.log(`Country: ${account.country}`);
    
    // Check if we're in the right mode
    const isTestMode = process.env.STRIPE_SECRET_KEY.startsWith('sk_test_');
    console.log(`Mode: ${isTestMode ? 'TEST' : 'LIVE'}`);
    
    if (isTestMode) {
      console.log('✅ You are in TEST mode - this is correct for development');
    } else {
      console.log('⚠️  You are in LIVE mode - make sure this is intentional');
    }
    
  } catch (error) {
    console.log('❌ Error getting account info:', error.message);
  }

  console.log('\n📋 Let me show you ALL available prices in your account:');
  try {
    const prices = await stripe.prices.list({ active: true, limit: 50 });
    console.log(`Found ${prices.data.length} active prices:`);
    
    if (prices.data.length === 0) {
      console.log('❌ No active prices found. You need to create products first.');
      console.log('\n📝 Quick Steps:');
      console.log('1. Go to https://dashboard.stripe.com');
      console.log('2. Make sure you\'re in TEST mode (toggle in top right)');
      console.log('3. Click "Products" in the sidebar');
      console.log('4. Click "+ Add product"');
      console.log('5. Create your monthly and yearly products');
    } else {
      prices.data.forEach((price, index) => {
        const amount = price.unit_amount ? `$${(price.unit_amount / 100).toFixed(2)}` : 'Variable';
        const interval = price.recurring?.interval || 'one-time';
        const isMonthly = price.id === monthlyPriceId;
        const isYearly = price.id === yearlyPriceId;
        const marker = isMonthly ? ' ← YOUR MONTHLY' : (isYearly ? ' ← YOUR YEARLY' : '');
        
        console.log(`${index + 1}. ${price.id}: ${amount} ${price.currency.toUpperCase()} / ${interval}${marker}`);
      });
      
      // Check if your specific prices are in the list
      const foundMonthly = prices.data.find(p => p.id === monthlyPriceId);
      const foundYearly = prices.data.find(p => p.id === yearlyPriceId);
      
      if (!foundMonthly) {
        console.log('\n❌ Your monthly Price ID is not found in this account');
      }
      if (!foundYearly) {
        console.log('\n❌ Your yearly Price ID is not found in this account');
      }
      
      if (!foundMonthly || !foundYearly) {
        console.log('\n💡 Possible solutions:');
        console.log('1. Make sure you\'re logged into the correct Stripe account');
        console.log('2. Make sure you\'re in TEST mode (not live mode)');
        console.log('3. Make sure you\'ve created the products');
        console.log('4. Check that your secret key matches the account');
      }
    }
    
  } catch (error) {
    console.log('❌ Error listing prices:', error.message);
  }
}

testSpecificPrices().catch(console.error);
