#!/usr/bin/env node

require('dotenv').config();
const Stripe = require('stripe');

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

async function testYourPrice() {
  console.log('🧪 Testing Your Specific Price ID\n');

  const yearlyPriceId = 'price_1SGRfRBj2yIrR2RDBvjnxYQa';

  console.log('Testing Yearly Price ID:', yearlyPriceId);
  try {
    const yearlyPrice = await stripe.prices.retrieve(yearlyPriceId);
    console.log('✅ SUCCESS! Yearly Price Found:');
    console.log(`   Amount: $${(yearlyPrice.unit_amount / 100).toFixed(2)} ${yearlyPrice.currency.toUpperCase()}`);
    console.log(`   Interval: ${yearlyPrice.recurring.interval}`);
    console.log(`   Product: ${yearlyPrice.product}`);
    console.log(`   Active: ${yearlyPrice.active}`);
    
    // Get product details
    const product = await stripe.products.retrieve(yearlyPrice.product);
    console.log(`   Product Name: ${product.name}`);
    console.log(`   Product Active: ${product.active}`);
    
    console.log('\n🎉 GREAT! Your Stripe integration should work now!');
    
    // Test creating a checkout session
    console.log('\n🧪 Testing Checkout Session Creation:');
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [
        {
          price: yearlyPriceId,
          quantity: 1,
        },
      ],
      success_url: 'http://localhost:3000/success?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: 'http://localhost:3000/cancel',
      metadata: {
        test: 'true',
        userId: 'test-user-123'
      }
    });

    console.log('✅ Checkout session created successfully!');
    console.log(`   Session ID: ${session.id}`);
    console.log(`   Checkout URL: ${session.url}`);
    
    console.log('\n📝 Update your .env file with:');
    console.log(`STRIPE_PREMIUM_YEARLY_PRICE_ID="${yearlyPriceId}"`);
    
    if (yearlyPrice.currency === 'cad') {
      console.log('\n💡 Note: Your price is in CAD, which is perfect for Canadian users!');
    }
    
  } catch (error) {
    console.log('❌ Yearly Price Error:', error.message);
    
    if (error.message.includes('No such price')) {
      console.log('\n💡 Possible issues:');
      console.log('1. The price might not be active yet (try refreshing in Stripe dashboard)');
      console.log('2. There might be a delay in Stripe\'s API');
      console.log('3. You might be in a different Stripe account');
      
      console.log('\n🔧 Try this:');
      console.log('1. Go to your Stripe dashboard');
      console.log('2. Click on the product');
      console.log('3. Make sure the price is marked as "Active"');
      console.log('4. Wait a few minutes and try again');
    }
  }
}

testYourPrice().catch(console.error);
