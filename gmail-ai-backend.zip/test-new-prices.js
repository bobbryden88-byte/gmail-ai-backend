#!/usr/bin/env node

require('dotenv').config();
const Stripe = require('stripe');

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

async function testNewPrices() {
  console.log('🧪 Testing Your New Price IDs\n');

  const monthlyPriceId = 'price_1SGRf0Bj2yIrR2RDT2BqPZ6X';
  const yearlyPriceId = 'price_1SGRfRBj2yIrR2RDBvjnxYQa';

  console.log('Testing Monthly Price ID:', monthlyPriceId);
  try {
    const monthlyPrice = await stripe.prices.retrieve(monthlyPriceId);
    console.log('✅ Monthly Price Found:');
    console.log(`   Amount: $${(monthlyPrice.unit_amount / 100).toFixed(2)} ${monthlyPrice.currency.toUpperCase()}`);
    console.log(`   Interval: ${monthlyPrice.recurring.interval}`);
    console.log(`   Product: ${monthlyPrice.product}`);
    console.log(`   Active: ${monthlyPrice.active}`);
  } catch (error) {
    console.log('❌ Monthly Price Error:', error.message);
  }

  console.log('\nTesting Yearly Price ID:', yearlyPriceId);
  try {
    const yearlyPrice = await stripe.prices.retrieve(yearlyPriceId);
    console.log('✅ Yearly Price Found:');
    console.log(`   Amount: $${(yearlyPrice.unit_amount / 100).toFixed(2)} ${yearlyPrice.currency.toUpperCase()}`);
    console.log(`   Interval: ${yearlyPrice.recurring.interval}`);
    console.log(`   Product: ${yearlyPrice.product}`);
    console.log(`   Active: ${yearlyPrice.active}`);
  } catch (error) {
    console.log('❌ Yearly Price Error:', error.message);
  }

  console.log('\n🔍 Testing Environment Variables:');
  console.log(`Monthly Price ID from .env: ${process.env.STRIPE_PREMIUM_MONTHLY_PRICE_ID}`);
  console.log(`Yearly Price ID from .env: ${process.env.STRIPE_PREMIUM_YEARLY_PRICE_ID}`);

  console.log('\n🧪 Testing Checkout Session Creation:');
  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [
        {
          price: monthlyPriceId,
          quantity: 1,
        },
      ],
      success_url: 'http://localhost:3000/success?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: 'http://localhost:3000/cancel',
      metadata: {
        test: 'true',
        userId: 'test-user-123'
      }
    });

    console.log('✅ Checkout session created successfully!');
    console.log(`   Session ID: ${session.id}`);
    console.log(`   Checkout URL: ${session.url}`);
    
  } catch (error) {
    console.log('❌ Checkout session error:', error.message);
  }

  console.log('\n📋 All Products in Your Account:');
  try {
    const products = await stripe.products.list({ limit: 10 });
    console.log(`Found ${products.data.length} products:`);
    products.data.forEach((product, index) => {
      console.log(`${index + 1}. ${product.name} (ID: ${product.id})`);
    });
  } catch (error) {
    console.log('❌ Error listing products:', error.message);
  }

  console.log('\n📋 All Active Prices in Your Account:');
  try {
    const prices = await stripe.prices.list({ active: true, limit: 20 });
    console.log(`Found ${prices.data.length} active prices:`);
    prices.data.forEach((price, index) => {
      const amount = price.unit_amount ? `$${(price.unit_amount / 100).toFixed(2)}` : 'Variable';
      const interval = price.recurring?.interval || 'one-time';
      const isMonthly = price.id === monthlyPriceId;
      const isYearly = price.id === yearlyPriceId;
      const marker = isMonthly ? ' ← YOUR MONTHLY' : (isYearly ? ' ← YOUR YEARLY' : '');
      
      console.log(`${index + 1}. ${price.id}: ${amount} ${price.currency.toUpperCase()} / ${interval}${marker}`);
    });
  } catch (error) {
    console.log('❌ Error listing prices:', error.message);
  }
}

testNewPrices().catch(console.error);
